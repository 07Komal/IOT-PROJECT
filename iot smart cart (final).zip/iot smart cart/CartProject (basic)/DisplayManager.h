#pragma once

namespace DisplayManager {
  void begin();
  void printHelp();
  void printCart();
}
