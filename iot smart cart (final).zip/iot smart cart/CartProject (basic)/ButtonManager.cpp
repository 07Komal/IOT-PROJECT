#include "ButtonManager.h"
#include "Config.h"

static ButtonManager::Mode mode = ButtonManager::ADD;
static unsigned long lastDebounce = 0;
static void (*resetCb)() = nullptr;

void ButtonManager::begin() {
  pinMode(ADD_BUTTON_PIN, INPUT);
  pinMode(REMOVE_BUTTON_PIN, INPUT);
  pinMode(RESET_BUTTON_PIN, INPUT);
}

void ButtonManager::poll() {
  if (millis() - lastDebounce < 200) return;

  if (digitalRead(ADD_BUTTON_PIN)) {
    mode = ButtonManager::ADD;
    Serial.println("[Add Mode]");
    lastDebounce = millis();
  }
  else if (digitalRead(REMOVE_BUTTON_PIN)) {
    mode = ButtonManager::REMOVE;
    Serial.println("[Remove Mode]");
    lastDebounce = millis();
  }
  else if (digitalRead(RESET_BUTTON_PIN)) {
    if (resetCb) resetCb();
    lastDebounce = millis();
  }
}

ButtonManager::Mode ButtonManager::currentMode() {
  return mode;
}

bool ButtonManager::isAddMode() {
  return mode == ButtonManager::ADD;
}

void ButtonManager::onReset(void (*fn)()) {
  resetCb = fn;
}
