#pragma once
#include "Inventory.h"
#include <Arduino.h>

struct CartItem {
  const char* name;
  uint8_t     qty;
  int         price;
};

namespace CartManager {
  void begin();
  void addItem(int inventoryIndex);
  void removeItem(int inventoryIndex);
  void resetCart();
  int  getTotal();
  const CartItem* getItems(uint8_t &outCount);
}
