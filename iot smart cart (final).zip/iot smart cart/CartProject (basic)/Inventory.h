#pragma once
#include <Arduino.h>

struct InventoryItem {
  const char* name;
  const char* rfid;
  int price;
};

namespace Inventory {
  extern const InventoryItem items[];
  extern const uint8_t itemCount;
  int findIndex(const String& uid);
}
