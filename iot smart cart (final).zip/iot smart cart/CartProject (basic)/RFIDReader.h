#pragma once
#include <Arduino.h>

namespace RFIDReader {
  void begin();
  void poll();
  void setTagCallback(void (*fn)(const String& uid));
}
