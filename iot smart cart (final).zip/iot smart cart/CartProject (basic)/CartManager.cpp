#include "CartManager.h"
#include "Config.h"

static CartItem cart[MAX_CART_ITEMS];
static uint8_t  cartCount = 0;
static int      total    = 0;

void CartManager::begin() {
  cartCount = 0;
  total     = 0;
}

void CartManager::addItem(int idx) {
  auto &inv = Inventory::items[idx];
  for (uint8_t i = 0; i < cartCount; i++) {
    if (cart[i].name == inv.name) {
      cart[i].qty++;
      total += inv.price;
      return;
    }
  }
  if (cartCount < MAX_CART_ITEMS) {
    cart[cartCount++] = { inv.name, 1, inv.price };
    total += inv.price;
  }
}

void CartManager::removeItem(int idx) {
  auto &inv = Inventory::items[idx];
  for (uint8_t i = 0; i < cartCount; i++) {
    if (cart[i].name == inv.name && cart[i].qty > 0) {
      cart[i].qty--;
      total -= inv.price;
      if (cart[i].qty == 0) {
        for (uint8_t j = i; j < cartCount - 1; j++) {
          cart[j] = cart[j+1];
        }
        cartCount--;
      }
      return;
    }
  }
}

void CartManager::resetCart() {
  cartCount = 0;
  total     = 0;
}

int CartManager::getTotal() {
  return total;
}

const CartItem* CartManager::getItems(uint8_t &outCount) {
  outCount = cartCount;
  return cart;
}
