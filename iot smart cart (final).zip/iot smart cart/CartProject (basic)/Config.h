#pragma once

#define SS_PIN            5
#define RST_PIN           22

#define ADD_BUTTON_PIN    15
#define REMOVE_BUTTON_PIN 2
#define RESET_BUTTON_PIN  4

#define MAX_CART_ITEMS    7

#define BAUD_RATE         9600
