#include "Inventory.h"

const InventoryItem Inventory::items[] = {
  { "Tata salt",   "C3 47 09 35", 20 },
  { "Milk Powder", "92 8D DF A4", 50 },
  { "Pacha Arasi", "A2 D0 78 D9", 50 },
  { "Ball Pen",    "02 3E 56 D9", 10 },
  { "Notebook",    "E3 27 75 FA", 30 },
  { "Pencil",      "42 03 54 D9",  5 },
  { "Eraser",      "D2 6D D6 A4",  3 }
};
const uint8_t Inventory::itemCount = sizeof(items) / sizeof(items[0]);

int Inventory::findIndex(const String& uid) {
  for (uint8_t i = 0; i < itemCount; i++) {
    if (uid == String(items[i].rfid)) return i;
  }
  return -1;
}
