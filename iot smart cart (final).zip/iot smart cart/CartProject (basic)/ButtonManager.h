#pragma once
#include <Arduino.h>

namespace ButtonManager {
  enum Mode { ADD, REMOVE };

  void    begin();
  void    poll();
  Mode    currentMode();
  bool    isAddMode();
  void    onReset(void (*fn)());
}
