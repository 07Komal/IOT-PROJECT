#include "RFIDReader.h"
#include <SPI.h>
#include <MFRC522.h>
#include "Config.h"

static MFRC522     mfrc522(SS_PIN, RST_PIN);
static void      (*tagCb)(const String&) = nullptr;

void RFIDReader::begin() {
  SPI.begin();
  mfrc522.PCD_Init();
}

void RFIDReader::poll() {
  if (!mfrc522.PICC_IsNewCardPresent() ||
      !mfrc522.PICC_ReadCardSerial()) return;

  String uid;
  for (byte i = 0; i < mfrc522.uid.size; i++) {
    uid += String(mfrc522.uid.uidByte[i] < 0x10 ? " 0" : " ");
    uid += String(mfrc522.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  uid = uid.substring(1);  // drop leading space

  if (tagCb) tagCb(uid);

  mfrc522.PICC_HaltA();
  mfrc522.PCD_StopCrypto1();
}

void RFIDReader::setTagCallback(void (*fn)(const String&)) {
  tagCb = fn;
}
