import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler

# Step 1: Simulate historical sales data
def generate_sample_data():
    dates = pd.date_range(start="2024-01-01", periods=30, freq='W')
    data = []
    np.random.seed(42)
    for product in ["Milk", "Bread", "Eggs"]:
        sales = np.abs(np.random.normal(loc=20, scale=5, size=len(dates)).astype(int))
        for date, qty in zip(dates, sales):
            data.append({"product": product, "date": date, "quantity": qty})
    return pd.DataFrame(data)

df = pd.read_csv("dataset.csv", parse_dates=["date"])


# Step 2: Prepare data for LSTM
def prepare_lstm_data(df, product, window_size=4):
    df_p = df[df['product'] == product].sort_values(by='date')
    scaler = MinMaxScaler()
    series = scaler.fit_transform(df_p[['quantity']]).flatten()

    X, y = [], []
    for i in range(len(series) - window_size):
        X.append(series[i:i+window_size])
        y.append(series[i+window_size])
    X = np.array(X)
    y = np.array(y)
    X = X.reshape((X.shape[0], X.shape[1], 1))
    return X, y, scaler, df_p

# Step 3: Build and train LSTM model
def train_lstm_model(X, y):
    model = Sequential()
    model.add(LSTM(50, activation='relu', input_shape=(X.shape[1], 1)))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')
    model.fit(X, y, epochs=100, verbose=0)
    return model

# Predict demand for a given product
def predict_demand(df, product):
    X, y, scaler, df_p = prepare_lstm_data(df, product)
    model = train_lstm_model(X, y)

    last_seq = df_p['quantity'].values[-4:]
    scaled_last_seq = scaler.transform(last_seq.reshape(-1, 1)).flatten().reshape((1, 4, 1))
    predicted_scaled = model.predict(scaled_last_seq)[0][0]
    predicted_actual = scaler.inverse_transform([[predicted_scaled]])[0][0]

    print(f"\n🔮 Predicted demand for next week ({product}): {predicted_actual:.2f} units")
    return predicted_actual

# Run prediction for all products
for product in df['product'].unique():
    predict_demand(df, product)
