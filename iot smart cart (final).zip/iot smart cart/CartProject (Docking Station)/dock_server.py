from flask import Flask, render_template, request, jsonify
import serial
import threading

app = Flask(__name__)

# Global storage for the latest bill
current_bill = []    # list of tuples (name, qty, price)
current_total = 0

# Replace 'COM10' with your dock-ESP32 serial port (e.g. '/dev/ttyUSB0' on Linux)
dock_ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=1)

@app.route('/')
def index():
    return render_template('index.html',
                           bill=current_bill,
                           total=current_total)

@app.route('/bill', methods=['POST'])
def receive_bill():
    global current_bill, current_total
    data = request.get_json()
    items = data.get('items', [])
    current_bill = [(i['name'], i['qty'], i['price']) for i in items]
    current_total = data.get('total', 0)
    print(f"Bill received: {current_bill}, Total = ₹{current_total}")
    return jsonify(status='ok')

@app.route('/pay', methods=['POST'])
def pay():
    # Send the open command to the dock ESP32
    dock_ser.write(b'OPEN_GATE\n')
    print("→ Sent OPEN_GATE to dock ESP32")
    return jsonify(status='gate_opened')

def serial_listener():
    """Optional: print any messages coming back from the dock ESP32."""
    while True:
        if dock_ser.in_waiting:
            line = dock_ser.readline().decode('utf-8').strip()
            print("Dock ESP32:", line)

if __name__ == '__main__':
    # Start the serial listener in background
    threading.Thread(target=serial_listener, daemon=True).start()
    # Run the Flask app
    app.run(host='0.0.0.0', port=5001)
