from flask import Flask, render_template, request, redirect, url_for
import serial, threading

app = Flask(__name__)

current_bill = []
current_total = 0
dock_ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=1)

@app.route('/')
def index():
    return render_template('index.html',
                           bill=current_bill,
                           total=current_total)

@app.route('/bill', methods=['POST'])
def receive_bill():
    global current_bill, current_total
    data = request.get_json()
    current_bill  = [(i['name'], i['qty'], i['price']) for i in data['items']]
    current_total = data['total']
    print(f"Bill received: {current_bill}, Total = ₹{current_total}")
    return '', 204  # No content

@app.route('/pay', methods=['POST'])
def pay():
    global current_bill, current_total
    # Trigger the gate
    dock_ser.write(b'OPEN_GATE\n')
    print("→ Sent OPEN_GATE to dock ESP32")
    # Clear the bill
    current_bill.clear()
    current_total = 0
    # Redirect back to the index page
    return redirect(url_for('index'))

def serial_listener():
    while True:
        if dock_ser.in_waiting:
            print("Dock ESP32:", dock_ser.readline().decode().strip())

if __name__ == '__main__':
    threading.Thread(target=serial_listener, daemon=True).start()
    app.run(host='0.0.0.0', port=5001)
