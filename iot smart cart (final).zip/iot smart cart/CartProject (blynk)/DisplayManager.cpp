#include "DisplayManager.h"
#include "CartManager.h"
#include <Arduino.h>

void DisplayManager::begin() {
  Serial.println(F("\n=== Smart Cart Ready ==="));
  Serial.println(F("Buttons:"));
  Serial.println(F(" • [ADD] to enter Add Mode"));
  Serial.println(F(" • [REMOVE] to enter Remove Mode"));
  Serial.println(F(" • [RESET] to clear cart"));
  Serial.println(F("Scan RFID tags to add/remove items\n"));
}

void DisplayManager::printCart() {
  uint8_t count;
  auto items = CartManager::getItems(count);
  int total = CartManager::getTotal();

  Serial.println(F("\n--- Cart Contents ---"));
  Serial.println(F("Item\tQty\tPrice\tTotal"));
  Serial.println(F("-----------------------------"));
  for (uint8_t i = 0; i < count; i++) {
    const auto &ci = items[i];
    Serial.printf("%s\t%d\t₹%d\t₹%d\n",
      ci.name, ci.qty, ci.price, ci.qty * ci.price);
  }
  Serial.println(F("-----------------------------"));
  Serial.printf("Total Amount: ₹%d\n\n", total);
}
