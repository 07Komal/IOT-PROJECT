# dock_server.py
from flask import Flask, render_template, request, redirect, url_for
import serial, threading, csv
from datetime import datetime

app = Flask(__name__)

# ─── Configuration ────────────────────────────────────
SERIAL_PORT = '/dev/ttyUSB0'    # or 'COM10' on Windows
BAUD_RATE   = 9600
CSV_FILE    = 'sales_data.csv'  # demand‑forecast log

# ─── Global State ─────────────────────────────────────
current_bill  = []   # list of (name, qty, price)
current_total = 0

# ─── Serial Setup ────────────────────────────────────
try:
    dock_ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
    print(f"[+] Serial connected on {SERIAL_PORT}")
except serial.SerialException as e:
    print(f"[!] Could not open serial port {SERIAL_PORT}: {e}")
    dock_ser = None

def serial_listener():
    """Daemon thread to print any messages from the dock ESP32."""
    if not dock_ser:
        return
    while True:
        line = dock_ser.readline().decode('utf-8', errors='ignore').strip()
        if line:
            print(f"[Dock ESP32] {line}")

threading.Thread(target=serial_listener, daemon=True).start()

# ─── Routes ───────────────────────────────────────────

@app.route('/')
def index():
    """Render the billing page."""
    return render_template('index.html', bill=current_bill, total=current_total)

@app.route('/bill', methods=['POST'])
def receive_bill():
    """Receive the cart JSON, update state & save to CSV."""
    global current_bill, current_total
    data = request.get_json(force=True)
    raw = data.get('items', [])

    # Build bill list
    current_bill = []
    for item in raw:
        name  = item.get('name')
        qty   = int(item.get('qty', 0))
        price = float(item.get('price', 0.0))
        current_bill.append((name, qty, price))

    # Total
    current_total = data.get('total', sum(q * p for _, q, p in current_bill))

    # Append to CSV for demand prediction
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(CSV_FILE, 'a', newline='') as f:
        writer = csv.writer(f)
        for name, qty, price in current_bill:
            writer.writerow([ts, name, qty, price, qty * price])

    print(f"[+] Bill received: {current_bill}, Total=₹{current_total}")
    return '', 204

@app.route('/pay', methods=['POST'])
def pay():
    """Simulate payment: open gate, clear bill, redirect."""
    global current_bill, current_total
    if dock_ser:
        dock_ser.write(b'OPEN_GATE\n')
        print("[+] Sent OPEN_GATE to dock ESP32")
    current_bill = []
    current_total = 0
    return redirect(url_for('index'))

# ─── Main ─────────────────────────────────────────────

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
