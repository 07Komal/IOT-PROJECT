# demand_model.py

import pandas as pd
import numpy as np
from datetime import timedelta
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import joblib

# ─── 1) Load & preprocess ────────────────────────────
# Only use Date, Product, Quantity columns
df = pd.read_csv(
    "sales_data.csv",
    parse_dates=["Date"],
    usecols=["Date", "Product", "Quantity"]
)

# Rename for convenience
df = df.rename(columns={
    "Date": "date",
    "Product": "product",
    "Quantity": "qty"
})

# Aggregate in case you have multiple entries per day
df = df.groupby(["product", "date"], as_index=False)["qty"].sum()

# ─── 2) Reindex to fill missing dates for each product ──
products = df["product"].unique()
frames = []
for prod in products:
    sub = df[df["product"] == prod].set_index("date")
    # daily frequency from min→max
    idx = pd.date_range(sub.index.min(), sub.index.max(), freq="D")
    sub = sub.reindex(idx, fill_value=0).rename_axis("date").reset_index()
    sub["product"] = prod
    frames.append(sub)
df_full = pd.concat(frames, ignore_index=True)

# ─── 3) Feature engineering ───────────────────────────
WINDOW = 7

def make_features(group):
    g = group.sort_values("date").copy()
    # Lag features
    for lag in range(1, WINDOW + 1):
        g[f"lag_{lag}"] = g["qty"].shift(lag)
    # Rolling mean
    g["roll_mean"] = g["qty"].shift(1).rolling(WINDOW).mean()
    # Date parts
    g["dow"]   = g["date"].dt.dayofweek
    g["dom"]   = g["date"].dt.day
    g["month"] = g["date"].dt.month
    return g

df_feat = (
    df_full
    .groupby("product", group_keys=False)
    .apply(make_features)
    .dropna()
    .reset_index(drop=True)
)

FEATURES = [f"lag_{i}" for i in range(1, WINDOW + 1)] + \
           ["roll_mean", "dow", "dom", "month"]
TARGET   = "qty"

X = df_feat[FEATURES]
y = df_feat[TARGET]

# ─── 4) Train/Test & Model ───────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"Test RMSE: {rmse:.2f} units")

# Save the model for later use
joblib.dump(model, "demand_rf_model.pkl")
print("Model saved as demand_rf_model.pkl")

# ─── 5) Prediction function ───────────────────────────
def predict_next_day(product_name):
    prod_df = df_full[df_full["product"] == product_name].sort_values("date")
    if len(prod_df) < WINDOW:
        raise ValueError(f"Not enough data for product '{product_name}'")
    last = prod_df.tail(WINDOW).reset_index(drop=True)

    # Build features for the next day
    feat = {}
    for lag in range(1, WINDOW + 1):
        feat[f"lag_{lag}"] = last.loc[WINDOW - lag, "qty"]
    feat["roll_mean"] = last["qty"].mean()
    next_date = last.loc[WINDOW - 1, "date"] + timedelta(days=1)
    feat["dow"]   = next_date.dayofweek
    feat["dom"]   = next_date.day
    feat["month"] = next_date.month

    Xp = pd.DataFrame([feat])
    m = joblib.load("demand_rf_model.pkl")
    pred = m.predict(Xp)[0]
    return max(0, round(pred))

# ─── 6) Demo ───────────────────────────────────────────
if __name__ == "__main__":
    print("\n🔮 Predicted demand for tomorrow:")
    for prod in products:
        p = predict_next_day(prod)
        print(f" • {prod}: {p} units")
