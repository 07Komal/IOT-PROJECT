// BlynkConfig.h
#ifndef BLYNKCONFIG_H
#define BLYNKCONFIG_H

// ─────────────── REQUIRED by Blynk IoT v1.3+ ───────────────
#define BLYNK_TEMPLATE_ID "TMPL3quhiW3Yb"
#define BLYNK_TEMPLATE_NAME "smart cart"
#define BLYNK_DEVICE_NAME "smart cart"
// ────────────────────────────────────────────────────────────

#define BLYNK_AUTH_TOKEN    "LDKn7LYHjpeqKW43EdS8tqcVc5n7XDYw"  // ← the device Auth Token
#define WIFI_SSID           "Pranav"
#define WIFI_PASS           "Msk3731453"

#endif // BLYNKCONFIG_H
