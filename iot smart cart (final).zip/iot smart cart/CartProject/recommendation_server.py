from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)

class RecommendationEngine:
    def __init__(self, rules_file="association_rules.csv"):
        self.rules = pd.read_csv(rules_file)
        self.rules['antecedents'] = self.rules['antecedents'].apply(
            lambda x: set(eval(x.replace("frozenset", "")))
        )
        self.rules['consequents'] = self.rules['consequents'].apply(
            lambda x: set(eval(x.replace("frozenset", "")))
        )

    def get_recommendations(self, product):
        relevant_rules = self.rules[self.rules['antecedents'].apply(
            lambda x: product.lower() in {item.lower() for item in x}
        )]
        recommendations = set()
        for cons in relevant_rules['consequents']:
            recommendations.update(cons)
        recommendations.discard(product)
        return list(recommendations)[:3]

engine = RecommendationEngine("association_rules.csv")

@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.get_json()
    product = data.get("item", "")
    if not product:
        return "No item provided", 400
    recos = engine.get_recommendations(product)
    if recos:
        return " | ".join(recos)
    else:
        return "No recommendations"

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
