import csv
import random
from datetime import datetime, timedelta

# Item list: (product, price)
items = [
    ("yogurt", 20),
    ("whole milk", 50),
    ("citrus fruit", 50),
    ("coffee", 10),
    ("margarine", 30),
    ("soda", 5),
    ("pip fruit", 3)
]

# Date range: last 30 days
start_date = datetime(2025, 3, 22)
days = 30

with open("sales_data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Date", "Product", "Quantity", "price", "total"])

    for day in range(days):
        date = (start_date + timedelta(days=day)).strftime("%Y-%m-%d")
        for product, price in items:
            # Simulate some days with no sales, some with high sales
            qty = random.choices(
                [0, 1, 2, 3, 4, 5, 6],
                weights=[0.1, 0.2, 0.25, 0.2, 0.15, 0.07, 0.03]
            )[0]
            if qty == 0:
                continue
            total = qty * price
            writer.writerow([date, product, qty, price, total])
