import pandas as pd
import numpy as np
from datetime import timedelta
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import joblib

# ─── 1) Load & preprocess ────────────────────────────
# Only use Date, Product, Quantity columns
df = pd.read_csv(
    "sales_data.csv",
    usecols=["Date", "Product", "Quantity"]
)

# Rename for convenience and ensure datetime dtype
df = df.rename(columns={
    "Date": "date",
    "Product": "product",
    "Quantity": "qty"
})
# Convert to datetime and strip time portion
df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.normalize()
# Drop rows where date parsing failed
df = df.dropna(subset=["date"])

# Aggregate in case you have multiple entries per day
df = df.groupby(["product", "date"], as_index=False)["qty"].sum()

# ─── 2) Reindex to fill missing dates for each product ──
products = df["product"].unique()
frames = []
for prod in products:
    sub = df[df["product"] == prod].set_index("date")
    idx = pd.date_range(sub.index.min(), sub.index.max(), freq="D")
    sub = sub.reindex(idx, fill_value=0).rename_axis("date").reset_index()
    sub["product"] = prod
    frames.append(sub)

df_full = pd.concat(frames, ignore_index=True)

# ─── 3) Feature engineering ───────────────────────────
WINDOW = 7

def make_features(group):
    g = group.sort_values("date").copy()
    # Lag features
    for lag in range(1, WINDOW + 1):
        g[f"lag_{lag}"] = g["qty"].shift(lag)
    # Rolling mean of past WINDOW days
    g["roll_mean"] = g["qty"].shift(1).rolling(WINDOW).mean()
    # Date parts
    g["dow"] = g["date"].dt.dayofweek
    g["dom"] = g["date"].dt.day
    g["month"] = g["date"].dt.month
    return g

# Build feature DataFrame
df_feat = (
    df_full
    .groupby("product", group_keys=False)
    .apply(make_features)
    .dropna()
    .reset_index(drop=True)
)

FEATURES = [f"lag_{i}" for i in range(1, WINDOW + 1)] + ["roll_mean", "dow", "dom", "month"]
TARGET = "qty"

X = df_feat[FEATURES]
y = df_feat[TARGET]

# ─── 4) Train/Test & Model ───────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"Test RMSE: {rmse:.2f} units")
# Save trained model
joblib.dump(model, "demand_rf_model.pkl")
print("Model saved as demand_rf_model.pkl")

# ─── 5) Prediction functions ─────────────────────────
def predict_next_day(product_name):
    """
    Predicts demand for the next single day for a product.
    """
    prod_df = df_full[df_full["product"] == product_name].sort_values("date")
    if len(prod_df) < WINDOW:
        raise ValueError(f"Not enough data for product '{product_name}'")
    last = prod_df.tail(WINDOW).reset_index(drop=True)

    # Build feature dict
    feat = {f"lag_{lag}": last.loc[WINDOW - lag, "qty"] for lag in range(1, WINDOW + 1)}
    feat["roll_mean"] = last["qty"].mean()
    next_date = last.loc[WINDOW - 1, "date"] + timedelta(days=1)
    feat.update({
        "dow": next_date.dayofweek,
        "dom": next_date.day,
        "month": next_date.month
    })

    Xp = pd.DataFrame([feat])
    m = joblib.load("demand_rf_model.pkl")
    return max(0, round(m.predict(Xp)[0]))


def predict_next_n_days(product_name, days):
    """
    Rolling multi-day forecast; returns list of daily predictions.
    """
    prod_df = df_full[df_full["product"] == product_name].sort_values("date").copy()
    if len(prod_df) < WINDOW:
        raise ValueError(f"Not enough data for product '{product_name}'")
    last = prod_df.tail(WINDOW).copy().reset_index(drop=True)
    m = joblib.load("demand_rf_model.pkl")
    preds = []

    for _ in range(days):
        feat = {f"lag_{lag}": last.loc[WINDOW - lag, "qty"] for lag in range(1, WINDOW + 1)}
        feat["roll_mean"] = last["qty"].mean()
        next_date = last.loc[WINDOW - 1, "date"] + timedelta(days=1)
        feat.update({
            "dow": next_date.dayofweek,
            "dom": next_date.day,
            "month": next_date.month
        })
        Xp = pd.DataFrame([feat])
        pred = max(0, round(m.predict(Xp)[0]))
        preds.append(pred)
        # Slide window
        next_row = pd.DataFrame({"date": [next_date], "qty": [pred]})
        last = pd.concat([last.iloc[1:], next_row], ignore_index=True)

    return preds


def predict_next_week(product_name):
    """Returns aggregate demand over next 7 days."""
    return sum(predict_next_n_days(product_name, days=7))


def predict_next_month(product_name):
    """Returns aggregate demand over next 30 days."""
    return sum(predict_next_n_days(product_name, days=30))

# ─── 6) Demo ───────────────────────────────────────────
if __name__ == "__main__":
    print("\n🔮 Predicted demand for tomorrow:")
    for prod in products:
        print(f" • {prod}: {predict_next_day(prod)} units")

    print("\n📦 Total predicted demand for next week:")
    for prod in products:
        print(f" • {prod}: {predict_next_week(prod)} units")

    print("\n📦 Total predicted demand for next month:")
    for prod in products:
        print(f" • {prod}: {predict_next_month(prod)} units")
